  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="<?= base_url(); ?>Login" class="logo mr-auto"><img src="<?= base_url(); ?>assets/img/logo.png" alt=""></a>
      <!-- <h1 class="logo mr-auto"><a href="index.html">Medicio</a></h1> -->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="<?= base_url(); ?>Login">Home</a></li>
          <!--<li><a href="<?= base_url(); ?>SRMS/about">About</a></li>-->
          <li><a href="<?= base_url(); ?>SRMS/announcement">Announcement</a></li>
          <li><a href="<?= base_url(); ?>SRMS/faq">Help</a></li>
          <li><a href="<?= base_url(); ?>Login/login">Login</a></li>
        </ul>
      </nav><!-- .nav-menu -->


    </div>
  </header>